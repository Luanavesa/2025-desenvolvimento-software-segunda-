﻿ int[] array = new int[100];
        Random random = new Random();

        // Preencher o vetor com valores aleatórios
        for (int i = 0; i < array.Length; i++)
        {
            array[i] = random.Next(1, 1000);
        }

        Console.WriteLine("Vetor original:");
        Console.WriteLine(string.Join(", ", array));

        // Algoritmo Bubble Sort
        for (int i = 0; i < array.Length - 1; i++)
        {
            for (int j = 0; j < array.Length - i - 1; j++)
            {
                if (array[j] > array[j + 1])
                {
                    int temp = array[j];
                 array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
            }
        }

        Console.WriteLine("Vetor ordenado:");
        Console.WriteLine(string.Join(", ", array));
    
