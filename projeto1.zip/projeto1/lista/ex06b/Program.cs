﻿ int[] array = new int[100];
        Random random = new Random();

        // Preencher o vetor com valores aleatórios
        for (int i = 0; i < array.Length; i++)
        {
            array[i] = random.Next(1, 1000);
        }

        Console.WriteLine("Vetor original:");
        Console.WriteLine(string.Join(", ", array));

        // Algoritmo Bubble Sort
        Array.Sort(array);

        Console.WriteLine("Vetor ordenado:");
        Console.WriteLine(string.Join(", ", array));